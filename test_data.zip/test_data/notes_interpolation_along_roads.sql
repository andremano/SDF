---------------------------------------------------------------------------------------
-- In the case of OSM shapefiles obtained from geofabrik. Expressions valid for QGIS --
---------------------------------------------------------------------------------------

-- 1 Filter to obtain only main roads with:

     "fclass" IN ('primary','primary_link','tertiary','tertiary_link''secondary','secondary_link','trunk','trunk_link')


-- 2 Remove disconnected road segments using the 'Disconnected islands plugin'

-- 3 Dissolve by "name"

-- 4 Add a new decimal filed named 'score' and autofill it with:

    CASE WHEN "fclass" IN ('primary','primary_link') THEN 2
		WHEN "fclass" IN ('secondary','secondary_link') THEN 1.5 
		ELSE 1.2
		END
		
-- 5 Extract vertices every x meters using 'Points along geometry' (distance should be the same used for the isoplate generation via IDW)

-- 6 Use 'Sample raster values' to sample the raster values of a continuous raster generated from IDW interpolation based on the urban centers

-- 7 Exclude sampled values that are 0 or null

-- 8 Use field calculator to create a new field named 'centrality' defined as:

	if( "score" * "interpolated1" > maximum("interpolated1", group_by:="name"), 
	maximum( "interpolated1", group_by:="name"),
	"score" * "interpolated1") 
		-- if the centrality score of a given vertice when multiplied by the maximum value occuring among the vertices originating from the same line, then return that maximum value
		-- otherwise return the product of the multiplication of the centrality score of the vertice times the maximum centrality score among the vertices originating from the same line
   
       
	   19,84,105,150,193,264,489,695


0 thru 19 = 1
19 thru 84 = 2
84 thru 105 = 3
105 thru 150 = 4
150 thru 193 = 5
193 thru 264 = 6
264 thru 489 = 8
489 thru 99999 = 12


to_string(minx-minx*0.25)||','||to_string(max*1.25)||','||to_string(miny-miny*1.25)||','||to_string(maxy*1.25)



 (  ( "3_null@1"-(4000+1))*-1)+1  = valid
 
 (  ( "3_null@1"-(4000+1))*-1)+1
 
 